# **SAP on Azure OpenHack**

# Contents

[Lab Overview](#lab-overview)

[Challenge 1 : Deploying the SAP S/4 HANA landscape](#challenge-1--deploying-the-sap-s4-hana-landscape)

[Challenge 2 : SAP parameter tuning](#challenge-2--sap-parameter-tuning)

[Challenge 3 : SAP HANA Backup using Azure native tools](#challenge-3--sap-hana-backup-using-azure-native-tools)

[Challenge 4 : Securing Fiori access from internet](#challenge-4--securing-fiori-access-from-internet)

[Challenge 5 : Single sign-on for SAP Fiori using Azure AD](#challenge-5--single-sign-on-for-sap-fiori-using-azure-ad)

[Challenge 6 : HANA Performance Validation](#challenge-6--hana-performance-validation)

[Challenge 7 : Setup dashboards for the SAP environment](#challenge-7--setup-dashboards-for-the-sap-environment)

[Appendix](#appendix)

# Lab Overview

Contoso group is a UK based consumer electrical retail company. They had started an evaluation of moving to SAP S/4 HANA on Azure a few months ago. As part of the evaluation, the IT team had setup an S/4 HANA POC landscape in Azure. Due to business reasons this was put on hold and to save costs they decided to convert these VMs to custom images.

With leadership changes at Contoso they have now decided to revive the POC and do a complete technical validation of the solution. You have been tasked with reinstating the environment and setup a demo how moving to Azure simplifies end to end management and operations of their SAP deployment. Key areas which the IT leadership team is looking at are

- Infrastructure as Code for deployment and configuration.
- HA solution which will give them at least 99.95% availability.
- Azure native solutions for operations like Monitoring, Backup etc.
- Zero downtime for applying changes/patches.
- Securing web-based access to SAP from internet using a WAF.
- Single Sign-on with Azure Active directory
- Performance validation of SAP HANA




# Challenge 1 : Deploying the SAP S/4 HANA landscape

### Goal 


The goal of this exercise is to use the already existing image to deploy the SAP environment. Below is the High availability architecture for S/4 HANA which you need to deploy.


![S4setup image](images/s4setup.jpg)


## Task 1 : Check Shared Gallery for Images

All VMs to be deployed in this OpenHack uses custom VM images.  These images are published in Azure Shared Image Gallery  **s4hana1809.sles12**. Check that you can access the images for all the different VM types in the Image gallery.

[https://docs.microsoft.com/en-us/azure/virtual-machines/windows/shared-image-galleries](https://docs.microsoft.com/en-us/azure/virtual-machines/windows/shared-image-galleries)

### :point_right: Hint 

Shared Image gallery used in this Openhack is hosted in a different subscription. Remove the subscription filter to see the gallery **s4hana1809.sles12**

## Task 2:  Deploy the SAP environment 

Deploy the SAP environment using the Terraform template [https://github.com/saponazurehack/sap-hack-template](https://github.com/saponazurehack/sap-hack-template). 


The template requires following inputs:

1. **location** - Choose one of the Azure regions where the image is available. (EastUS2, CanadaCentral, FranceCentral, WestEurope, NorthEurope)
2. **rgname** (Optional) - Name of the Resource Group to deploy resources into. This defaults to SAP-Open-Hack.
3. **sshkeypath** -  Path to your SSH public key file to be used for logging into Linux VMs. If you don't have an SSH keypair generated already, generate one as described [here](#generating-ssh-keypair) before proceeding further.
4. **adminpassword** - Password for logging in to the Windows jumpbox (remember to create a strong password)

Rest of the variable values are picked up from terraform.tfvars file automatically

### :warning: Warning
All Linux VMs in your OpenHack landscape are configured to authenticate using an ssh key pair. You will provide your public key while executing the deployment using "terraform apply". **You will then need to copy your private key to the Windows jumpbox within the same deployment.**

Therefore, note that even though you can use your existing key pair for the hack, if you are working in a team and sharing the deployed landscape with your team members, it is recommended that you create a new key pair for the hack which can be shared within your hack team.


**Additional information**

To start the terraform deployment, follow the steps listed below

- Login to Azure cloud shell [https://shell.azure.com/](https://shell.azure.com/)
- Clone the GitHub repository [https://github.com/saponazurehack/sap-hack-template.git](https://github.com/saponazurehack/sap-hack-template.git)

`git clone https://github.com/saponazurehack/sap-hack-template.git`


![git clone init](images/gitclone.png)

- Go to the folder sap-hack-template and run

`terraform init`

This will initialize the terraform modules and download the azurerm resource provider

![terraform init](images/terraforminit.png)

- Now run apply and provide the required inputs to start the deployment.

It is possible to provide necessary inputs interactively or pass them as command line parameters.

`terraform apply`

**OR**

`terraform apply -var 'rgname=SAP-Open-hack' -var 'location=EastUS2' -var 'sshkeypath=~/.ssh/id_rsa.pub'`

![terraform apply](images/terraformapply.png)

When prompted, confirm with a **yes** to start the deployment

![terraform confirm](images/terraformconfirm.png)

- Wait for the deployment to complete. This will take approx. 10-15 minutes



## Task 3 : Explore all the deployed resources

 - Check that you can login to SAP using SAP GUI

 - Check that you can connect to HANA database using HANA Studio

 - Check the status of HANA System Replication using HANA studio

 - Check the status of all the 3 clusters (HANA, NFS and ASCS). This can be done using SSH tools using command `crm status` or using **HAWK UI**

[https://documentation.suse.com/sle-ha/15-SP1/html/SLE-HA-all/cha-conf-hawk2.html](https://documentation.suse.com/sle-ha/15-SP1/html/SLE-HA-all/cha-conf-hawk2.html)

HAWK UI requires to login as user which is part of haclient group. Command to add tstadm user to haclient group 
`usermod -a -G haclient tstadm`


### :point_right: Hint 

**Tools required for this OpenHack are already installed in the Windows Jumpbox VM, they are available either as Desktop shortcuts or in C:\Software**

**SAPGUI:** You need to create a new connection

 ![sapgui](images/sapgui.png)

**HANA Studio:** Available in **C:\Software\eclipse** , HANA database connections SYSTEMDB and SAPHANADB already created. You will need to login using the HANA Database credentials provided.

![hana studio](images/hana_studio.png)

![db logon](images/db_logon.png)

![hana db status](images/haandb.png)

For logging into the VMs you can either use **SSH Client MobaXterm** (All connections are already created) or **Putty**. You will need to **provide your SSH Private Key** to each connection.


## :checkered_flag: Results

- You have deployed an SAP S/4HANA environment using given Terraform template
- You have become familiar to components of the SAP landscape you just deployed
- You are now be able to login to the SAP system using various tools
- High availability clustering is setup correctly for NFS, HANA and Central Services
- HANA System Replication has been enabled













## Challenge 2 : SAP Parameter tuning

### Goal


The goal of this challenge is to tune SUSE operating system to SAP recommendation with minimum administrative efforts and apply changes with almost zero downtime.


## Task 1: Tune SAP parameter with minimum administrative effort

You have found that the SAP HANA VMs are not tuned as per the SAP recommendations.  Some of the recommendations in SAP note # 2382421 are not applied.  In this challenge you need to tune the parameters as per this SAP note except `net.ipv4.tcp_timestamps` which needs to be set to 0 for Azure


### :point_right: Hint


In SLES there are couple of tools available to tune the OS for running SAP namely sapconf and saptune. Sapconf performs minimum standard changes whereas saptune can apply SAP notes individually or bunch of notes relevant to the solution like SAP HANA, NetWeaver etc. You can use the customize option of saptune to edit a parameter within the note and apply it.


You will need to install saptune by running `zypper install saptune`. Since the VMs are rebuilt using the images you may need to re-register the repos to point to Azure SMT using the steps below before installing saptune

```suse
rm /etc/SUSEConnect
rm -f /etc/zypp/{repos,services,credentials}.d/*
rm -f /usr/lib/zypp/plugins/services/*
sed -i '/^# Added by SMT reg/,+1d'; /etc/hosts
/usr/sbin/registercloudguest --force-new
```

Useful saptune commands (For solutions substitute note with solution in the below commands)

```saptune
saptune note list
saptune note simulate <note number>
saptune note apply <note number>
saptune note customise <note number>
(opens a vi editor where the note parameters value can be customized)
```



## Task 2: Reboot VMs with least business outage 


 You need to ensure that these changes persist after reboot. Also confirm that the **HANA** failover works fine.


### :point_right: Hint 

This could be done in several ways. You will be using some of the below commands to do this task

`crm node standby <nodename>` - Make the node offline for the cluster

`crm node online <nodename>` - Make the node online for the cluster

`crm cluster stop` - Stopping the cluster service on the node where it is executed

`crm cluster start` - Starting the cluster service on the node where it is executed

`crm resource migrate <resource name>` - Migrate a resource from one node to another

`crm resource clear <resource name>` - Remove migration constraints from resources

`crm resource cleanup <resource name>` - Cleanup any previous errors in the cluster



## :checkered_flag: Results

- You have tuned the OS parameters as per SAP note easily using the right tools.
- You have tested the HANA HA setup and tested the user experience during failover.








 



# Challenge 3 : SAP HANA Backup using Azure native tools

### Goal

SAP HANA, like other database, offers the possibility to backup to files. In addition, it also offers a backup API, which allows third-party backup tools to integrate directly with SAP HANA. Products like Azure Backup service, or Commvault are using this proprietary interface to trigger SAP HANA database or redo log backups. SAP HANA offers a third possibility, HANA backup based on storage snapshots. The focus of this challenge is to configure **Azure Backup for SAP HANA**.
 


## Task 1 :  Prepare HANA VMs for Azure Backup

Contoso Group have asked you to prepare SAP HANA virtual machines for Azure Backup using BACKINT API.

You need to perform all pre-requisites and setup network connectivity to allow Azure Backup to connect to SAP HANA database as per this document.

[https://docs.microsoft.com/en-us/azure/backup/tutorial-backup-sap-hana-db](https://docs.microsoft.com/en-us/azure/backup/tutorial-backup-sap-hana-db)


### :point_right: Hint 


Your HANA database is running over a 2 node highly available cluster. For this hack **configure it only on the active node**. 

Also, you may need to register your HANA virtual machines to access SUSE repos and install package unixODBC, if not already installed.

Run following commands as root to install unixODBC

`zypper install unixODBC`

You will need to create SAP HANA HDBUSERSTORE Key named SYSTEM for user SYSTEM for password less authentication.

Run following commands as tstadm on HANA virtual machine, the port here is ``30013``

Syntax

`hdbuserstore -i SET <KEY> host:port <USERNAME>`

Test the connection using following command.

`hdbsql -U SYSTEM`

On the hdbsql prompt, type \s to check the status and ensure you can connect.



## Task 2 : Run backup for HANA using Azure Backup

Contoso Group have asked you to create a backup configuration to meet their requirements and to start the first backup right away.

Contoso deem it sufficient to take full backups once a week over the weekend, but want to optimize the cost and time required for backup and restore by using an optimized backup and retention policy. In the scenario where a restore becomes necessary, they want to be able to restore with no more than 20 minutes of loss of data.

Create an appropriate backup and retention policy and backup your SAP HANA database using Azure Backup.


### :point_right: Hint 

The key steps are - create a recovery services vault, configure backup, create a backup policy and backup.

[https://docs.microsoft.com/en-us/azure/backup/tutorial-backup-sap-hana-db#create-a-recovery-service-vault](https://docs.microsoft.com/en-us/azure/backup/tutorial-backup-sap-hana-db#create-a-recovery-service-vault)


## :checkered_flag: Results

- You have configured and run Azure backup for HANA database











  
# Challenge 4 : Securing Fiori access from internet

### Goal

The goal of this challenge is to publish SAP Fiori launchpad using Azure Application gateway.

Contoso group wants to expose their SAP Fiori launchpad to internet. They would like to do this in a secure way using a gateway which can filter traffic to the SAP backend based on urls. Below are the requirements 
  -  Security team at Contoso have mandated that the endpoint is secured with TLSv1.2.
  -  TLS termination should happen at the Application Gateway. All gateway to backend communication will be in HTTP.
  -  Any attempt to access any url other than Fiori launchpad should not reach the SAP backend. It should be redirected to an external page ``http://www.microsoft.com``.  
  -  Fiori launchpad url should be customized to ``https://<dnsname>:443/openhackfiori``
  


## Task 1 :  Ensure Fiori launchpad is accessible

Ensure that Fiori launchpad is accessible with direct SAP url from within the jumpbox. URL for Fiori launchpad is

``http://tst-app-avm-0:8000/sap/bc/ui2/flp``

User openhack has a custom Fiori tile assigned to it called OpenHack Demo which opens SAP transaction code ``SM51`` within Fiori.

### :point_right: Hint 

- Ports defined in SAP are 8000 for HTTP and 8001 for HTTPS. Since TLS will terminate at Application Gateway, we will use use HTTP for SAP backend communication.





## Task 2 : Make SAP Fiori launchpad accessible from Internet 

You need to deploy Azure Application Gateway for this exercise. Below diagram explains how application gateway works. 

![App gateway image](https://docs.microsoft.com/en-us/azure/application-gateway/media/how-application-gateway-works/how-application-gateway-works.png)

The Application Gateway must conform to following requirements:
- Uses a DNS name label for Application Gateway public IP eg ``xxx.<region>.cloudapp.azure.com``.
- Must have a self signed certificate for above DNS name to setup the HTTPS listener in Application Gateway. 
  Generate the certificate using Powershell as described here [https://docs.microsoft.com/en-us/azure/application-gateway/create-ssl-portal](https://docs.microsoft.com/en-us/azure/application-gateway/create-ssl-portal)
- Application Gateway must conform to the SSL policy requirement stated previously, make changes if required.
- In order to achieve all the requirements mentioned you may be required to use path based routing in Application Gateway. Below are the urls which need to be whitelisted

```
/sap/public/icman*
/sap/bc/ui5_ui5*
/sap/public/bc/ui2*
/sap/bc/ui2*
/sap/opu/odata/ui2*
/sap/bc/gui/sap/its*
/sap/saml2/sp/acs/000
```
- Any attempt to access other urls not listed above must NOT reach SAP, instead be redirected to ``http://www.microsoft.com``. 


### :point_right: Hint 

- You will need an additional subnet within the existing VNET (by adding a new address space) for Application Gateway creation.
- Pay attention to NSG rules necessary for Application Gateway subnet as described here [https://docs.microsoft.com/en-us/azure/application-gateway/configuration-overview](https://docs.microsoft.com/en-us/azure/application-gateway/configuration-overview)
- Think about NSG changes required to allow traffic from App gateway to SAP subnet.
- You will need a custom probe for the SAP backend. 


## Task 3 : Create a short url for Fiori launchpad

You need to create short url for the Fiori launchpad of the format ``https://<dnsname>:443/openhackfiori``

### :point_right: Hint 

- To achieve the above requirement you need to create an additonal HTTP setting with override backend path.


### :heavy_check_mark: Validation 

To successfully complete this challenge you need to validate the following

 - Ensure that Fiori launchpad is accessible from internet using HTTPS only and with the short url ``https://<dnsname>:443/openhackfiori``
 - Check that TLS version is TLSv1.2 and there are no warnings or errors in the browser.
 - Try accessing end point ``https://<dnsname>:443/sap/opu/odata/iwbep/gwdemo_sp2``.  This url is not in the path based filters so you should be redirected to external site.


## :checkered_flag: Results

You have now demonstrated how SAP endpoints can be securely published to internet with the help of Azure Application Gateway.  








# Challenge 5 : Single sign-on for SAP Fiori using Azure AD

### Goal 

The goal of this challenge is to enable Single Sign On for SAP Fiori launchpad with Azure Active Directory.

With your help, Contoso Group have managed to roll out their first SAP Fiori application. The business wants to publish several more Fiori apps to new users. 
Since SAP user accounts are currently managed within SAP, the IT Director has asked you to explore Single sign-on (SSO) possibilities using Azure AD to simplify identity and access management. Amongst available options, you have proposed **SSO with Azure AD using SAML** and now need to demonstrate the following by creating a proof of concept:

- Integrate SAP Fiori with Azure AD using SAML (Service Provider initiated SSO).
- Control in Azure AD who has access to SAP Fiori.
- Enable your users to be automatically signed-in to SAP Fiori with their Azure AD accounts.

### :point_right: Pre-requisites
- You are able to access Fiori Launchpad via your Application Gateway using Azure public DNS name (eg ``xxx.westeurope.cloudapp.azure.com``) on HTTPS.

## Task 1 Setup a new demo tenant in Azure AD:  

- Create a new Azure AD tenant to be used with your OpenHack landscape.
- Create a user called **openhack** in Azure AD and note the password. The same user exists in SAP which you will later use for SAP configuration as well as testing.
- Add a new **Enterprise Application** of category **SAP Fiori** or **SAP Netweaver** from the gallery.
- Perform **Basic SAML Configuration** in your new Enterprise Application.

### :point_right: Hint 
- Download Certificate (Base64) and Federation Metadata XML, you will need these later.
- **Identifier (Entity ID)** can be anything but you must use same value in next task when configuring SAP **Local Provider**.
- Use Application Gateway url for SAP endpoints. Url required are already whitelisted as part of the previous exercise.
- Assertion Consumer Service URL in the openhack landscape ends in 000 (not 100 as per the example shown on screen).


## Task 2 Configure SAML in SAP:  

- Using transaction code ``SICF`` activate all services under ``/sap/bc/webdynpro`` and ``/sap/public/bc`` (You may need to first Deactivate and then Activate the entire tree)
- Create **SAML 2.0 Local Provider** in SAP using transaction code ``SAML2``
  (OR using ``http://tst-app-avm-0:8000/sap/bc/webdynpro/sap/saml2``).
- Add Azure AD as a **Trusted Provider** using the metadata and certificate downloaded previously.
- Reference [https://docs.microsoft.com/en-us/azure/active-directory/saas-apps/sap-fiori-tutorial](https://docs.microsoft.com/en-us/azure/active-directory/saas-apps/sap-fiori-tutorial)

### :point_right: Hint 
- Add the authentication context **PasswordProtectedTransport**.
- During SAML single sign-on, by default, Azure AD will pass the Name ID claim as ``<username>@yourdomain.onmicrosoft.com`` whereas the SAP User ID is ``<username>``. There are several possibilities to address this. One way is to use claim transformations in Azure AD. Another way is to leverage Alias in SAP user account.

![Claim Transformation image](images/AADClaimTransformation.png)

- In App gateway, create a rewrite rule (without any condition) associated to the SAP routing rules. The rule should add a custom header **ClientProtocol** set to **HTTPS** as shown in the screenshot below. Without this the SAML response validation by SAP will fail with error "Response did not arrive at correct destination". This can be checked using Security Diagnostic Tool mentioned in the next section. 

![customheader](images/customheader.jpg)




## Task 3 Test Azure AD Authentication, Single sign-on and Access:

Review your configuration including endpoint mapping and test authentication, single sign-on and access using following url:
``https://<your-appgw-dns>/openhackfiori`` 

(OR `https://<your-appgw-dns>/sap/bc/ui2/flp`)

### :point_right: Hint 
- If Azure AD authenticates but single sign-on doesn't work, you can use the **Security Diagnostic Tool** for troubleshooting:
  - Transaction code ``SICF`` --> Service ``/sap/bc/webdynpro/sap/SEC_DIAG_TOOL`` OR
  - ``http://tst-app-avm-0:8000/sap/bc/webdynpro/sap/sec_diag_tool``

## :checkered_flag: Results
- When you visit SAP Fiori Launchpad (``/openhackfiori`` OR ``/sap/bc/ui2/flp``) using a new **InPrivate browser window**, you are redirected to Azure AD
- You are able to authenticate using the pasowrd of user ``openhack@yourtenant.onmicrosoft.com``
- You are then redirected back to SAP Fiori launchpad and single sign-on without seeing SAP logon screen











# Challenge 6 : HANA performance validation


### Goal

The goal of this exercise is to validate the setup of HANA infrastrcture.

Contoso group have previously hosted SAP HANA using appliances. Due to the limitations with flexibility and high costs they have decided to use Azure instead for their new S/4 HANA instance.  Since this is their first SAP HANA deployment in cloud there is nervousness within the IT group at Contoso. They need a way to ensure that Azure infrastructure deployed to run S/4 HANA is fit for purpose and complies with all KPIs defined by SAP particulary with respect to underlying storage performance.

## Task 1 :  Setup and run HCMT 

SAP provides tools to check if the HANA infrastructure fulfills SAP's KPI for data throughput and latency.  
- For HANA 1.0 this could be achieved with **“SAP HANA Hardware Configuration Check Tool (HWCCT)**. 
- For HANA 2.0 there is a new tool available **SAP HANA Cloud Measurement Tool (HCMT)**.  

You will be using HCMT  to validate your HANA setup. See documentation here [https://help.sap.com/doc/af47cce52aaa4ed4992d42d3cf319d62/2.0/en-US/How_to_Use_the_SAP_HANA_Hardware_and_Cloud_Measurement_Tools_en.pdf](https://help.sap.com/doc/af47cce52aaa4ed4992d42d3cf319d62/2.0/en-US/How_to_Use_the_SAP_HANA_Hardware_and_Cloud_Measurement_Tools_en.pdf)


The tool is already downloaded and available in the directory `/hana/backup/HANA_perftools` of HANA node **tst-hana-vm-0**

- Install the tool and check different execution plans available. 
- Run a short test using the **quickcheck.json** execution plan. 
- Analyse the results using HANA measurements UI.


## Task 2 :  Check HANA storage configuration and validate using HCMT

In this task you need to **validate** the setup of HANA storage configuration. The execution plans available to check the HANA storage KPIs take several hours to finish. So this has been already executed and the output is avaialble under **C:\Software\HCMT** in the jumpbox.  

- Upload this file to the measurements page and analyse the results. 
- SAP published KPIs for HANA data and log volumes are as per below. Check for these metrics specifically. If value is not within the SAP published KPI the test will be marked as failed in the UI.

![hana kpi](images/hanakpi.jpg)

- Compare the IO setup for **/hana/data** and **/hana/log** volumes against SAP on Azure guidelines in the link below to list the differences so that you can explain it to the IT leadership at Contoso. Look specifically for the following **disk type, number of stripes, stripe size, write accelerator and cache** settings

[https://docs.microsoft.com/en-us/azure/virtual-machines/workloads/sap/hana-vm-operations-storage](https://docs.microsoft.com/en-us/azure/virtual-machines/workloads/sap/hana-vm-operations-storage)
 

### :point_right: Hint  

- Note that some of the tests will not be passed as we are using smaller non-certified VMs for our test deployment. 


## :checkered_flag: Results

- You now successfully verified the setup of  SAP HANA infrastructure and provided mechanism to check for KPIs set out by SAP when it comes to production deployment. 

















# Challenge 7 : Setup dashboards for the SAP environment

### Goal 

Use Azure monitor to check performance of the SAP environment and setup dashboards.

The IT leadership team has requested for an availability and performance dashboard for the SAP environment. The dashboard must contain key performance metrics and availability for all the SAP VMs that have been deployed. 

## Task : Setup Availability and Performance dashboard for SAP 

- Create a dashboard in Azure portal which provides availability and performance of all VMs associated with your S/4 HANA VMs. See sample dashboard below

![azuremonitor](images/azuremonitor.png)

- Create a PowerBI dashboard reporting the performance metrics of your S/4 HANA VMs. See sample dashboard below

![pbi](images/pbi.png)

### :point_right: Hint 

 Use Azure monitor for this exercise. Check what metrics are collected by default. There are several ways to visualize log and metric data stored in Azure Monitor. See below link for details

[https://docs.microsoft.com/en-us/azure/azure-monitor/visualizations](https://docs.microsoft.com/en-us/azure/azure-monitor/visualizations)



## :checkered_flag: Results
- You now have centralized dashboards reporting performance and availability of your SAP S/4 HANA.














# Appendix

### Generating SSH keypair

- Login to Azure cloud shell [https://shell.azure.com/](https://shell.azure.com/)
- Generate SSH keypair using the command `ssh-keygen` as shown in the screenshot below. Accept default values

  ![keygen](images/keygen.jpg)

- Use the public key (id_rsa.pub) for the deployment. Path will be /home/**username**/.ssh/id_rsa.pub
- Download the private key (/home/**username**/.ssh/id_rsa) to your desktop using the download button at the top. Copy it to the windows jumpbox. 
- Before you can use this key for logging in you need to convert it to **.ppk** format. In the jumpbox open **PuTTYgen**. Load the private key using the **Load** button.  You will get a message that key is imported as shown below.

  ![loadprivatekey](images/loadppk.jpg)

- Now use the **Save private key** option to save the private key in **ppk** format.


